"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { MapPin, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface LocationPickerProps {
  onLocationSelect: (location: { lat: number; lng: number; address: string }) => void
  defaultAddress?: string
}

export function LocationPicker({ onLocationSelect, defaultAddress = "" }: LocationPickerProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [location, setLocation] = useState<{ lat: number; lng: number; address: string } | null>(null)
  const [mapUrl, setMapUrl] = useState("")

  useEffect(() => {
    if (location) {
      // Create a static map URL using the location
      const newMapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${location.lat},${location.lng}&zoom=15&size=600x300&markers=color:red%7C${location.lat},${location.lng}&key=YOUR_API_KEY`
      setMapUrl(newMapUrl)

      // For demo purposes, we'll use a placeholder image instead of an actual Google Maps API call
      setMapUrl(
        `/placeholder.svg?height=300&width=600&text=Map+at+${location.lat.toFixed(4)},${location.lng.toFixed(4)}`,
      )
    }
  }, [location])

  const getLocationFromAddress = async (address: string) => {
    // In a real app, you would use a geocoding service to convert address to coordinates
    // For this demo, we'll simulate it with random coordinates near Uzbekistan
    const lat = 41.3 + Math.random() * 0.1
    const lng = 69.2 + Math.random() * 0.1

    return { lat, lng, address }
  }

  const getCurrentLocation = () => {
    setIsLoading(true)
    setError(null)

    if (!navigator.geolocation) {
      setError("Geolokatsiya brauzeringizda qo'llab-quvvatlanmaydi")
      setIsLoading(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords

        // In a real app, you would use reverse geocoding to get the address from coordinates
        // For this demo, we'll use a placeholder address
        const address = "Aniqlangan joylashuv"

        const locationData = { lat: latitude, lng: longitude, address }
        setLocation(locationData)
        onLocationSelect(locationData)
        setIsLoading(false)
      },
      (error) => {
        console.error("Geolocation error:", error)
        setError("Joylashuvni aniqlashda xatolik yuz berdi. Iltimos, manzilni qo'lda kiriting.")
        setIsLoading(false)
      },
      { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 },
    )
  }

  const handleAddressSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!defaultAddress) return

    setIsLoading(true)
    setError(null)

    try {
      const locationData = await getLocationFromAddress(defaultAddress)
      setLocation(locationData)
      onLocationSelect(locationData)
    } catch (err) {
      setError("Manzilni aniqlashda xatolik yuz berdi")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <Button type="button" variant="outline" className="flex-1" onClick={getCurrentLocation} disabled={isLoading}>
          {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <MapPin className="mr-2 h-4 w-4" />}
          Joylashuvni aniqlash
        </Button>

        <Button
          type="button"
          variant="outline"
          className="flex-1"
          onClick={handleAddressSubmit}
          disabled={isLoading || !defaultAddress}
        >
          Manzildan aniqlash
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {location && (
        <div className="border rounded-md overflow-hidden">
          <div className="bg-gray-100 w-full h-[200px] flex items-center justify-center relative">
            <img src={mapUrl || "/placeholder.svg"} alt="Joylashuv xaritasi" className="w-full h-full object-cover" />
            <div className="absolute bottom-2 right-2 bg-white p-2 rounded-md text-xs">
              {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
            </div>
          </div>
          <div className="p-3 bg-white">
            <p className="text-sm font-medium">Tanlangan joylashuv:</p>
            <p className="text-sm text-gray-600">{location.address}</p>
          </div>
        </div>
      )}
    </div>
  )
}
