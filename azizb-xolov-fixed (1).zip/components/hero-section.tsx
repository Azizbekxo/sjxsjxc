import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="w-full py-12 md:py-16 lg:py-20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="md:w-1/2 space-y-4">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
              Azizb Xolov Dastafka
            </h1>
            <p className="max-w-[600px] text-gray-500 md:text-xl">
              Boysun tumani bo'ylab oziq-ovqat, dori-darmon va boshqa mahsulotlarni tez va qulay yetkazib berish xizmati
            </p>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
              <h3 className="font-bold text-blue-600 mb-1">Bepul yetkazib berish!</h3>
              <p className="text-gray-600">Birinchi 5 ta buyurtma uchun yetkazib berish bepul</p>
            </div>
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <Link href="#buyurtma">
                Buyurtma berish
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="md:w-1/2">
            <div className="bg-blue-100 p-6 rounded-full w-[300px] h-[300px] flex items-center justify-center mx-auto">
              <img
                alt="Yetkazib berish xizmati"
                className="max-w-[250px]"
                src="/placeholder.svg?height=250&width=250"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
