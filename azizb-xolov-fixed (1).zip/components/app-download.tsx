"use client"

import Link from "next/link"
import { Smartphone, X } from "lucide-react"
import { useState } from "react"

export function AppDownload() {
  const [isVisible, setIsVisible] = useState(true)

  if (!isVisible) return null

  return (
    <div className="bg-blue-600 text-white py-2">
      <div className="container px-4 md:px-6 flex items-center justify-between">
        <div className="flex items-center">
          <Smartphone className="h-5 w-5 mr-2" />
          <span className="text-sm">
            Ilovamizni yuklab oling va 10% chegirma oling!
            <Link href="#" className="ml-2 underline font-medium">
              Yuklab olish
            </Link>
          </span>
        </div>
        <button onClick={() => setIsVisible(false)} className="text-white">
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  )
}
