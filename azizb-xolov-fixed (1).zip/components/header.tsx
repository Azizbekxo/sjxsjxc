"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { Menu, ShoppingCart, User, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export function Header() {
  const router = useRouter()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    // Check if user is logged in
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)
  }, [])

  const handleCartClick = () => {
    router.push("/cart")
  }

  const handleProfileClick = () => {
    if (isLoggedIn) {
      router.push("/profile")
    } else {
      router.push("/login")
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center">
          <button className="md:hidden mr-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-white font-bold">A</span>
            </div>
            <span className="text-xl font-bold text-blue-600">Azizb Xolov</span>
          </Link>
        </div>

        <nav className="hidden md:flex gap-6">
          <Link href="/" className="text-sm font-medium transition-colors hover:text-blue-600">
            Asosiy
          </Link>
          <Link href="/products" className="text-sm font-medium transition-colors hover:text-blue-600">
            Kategoriyalar
          </Link>
          <Link href="#narxlar" className="text-sm font-medium transition-colors hover:text-blue-600">
            Narxlar
          </Link>
          <Link href="#aloqa" className="text-sm font-medium transition-colors hover:text-blue-600">
            Aloqa
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          {isLoggedIn ? (
            <button
              onClick={handleProfileClick}
              className="hidden md:flex items-center text-sm font-medium transition-colors hover:text-blue-600"
            >
              <User className="h-5 w-5 mr-1" />
              Profil
            </button>
          ) : (
            <div className="hidden md:flex items-center gap-3">
              <Link href="/login" className="text-sm font-medium transition-colors hover:text-blue-600">
                Kirish
              </Link>
              <Button asChild variant="outline" size="sm">
                <Link href="/register">Ro'yxatdan o'tish</Link>
              </Button>
            </div>
          )}
          <Button onClick={handleCartClick} className="bg-blue-600 hover:bg-blue-700">
            <ShoppingCart className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Savatcha</span>
          </Button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="container md:hidden py-4 border-t">
          <nav className="flex flex-col space-y-4">
            <Link
              href="/"
              className="text-sm font-medium transition-colors hover:text-blue-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Asosiy
            </Link>
            <Link
              href="/products"
              className="text-sm font-medium transition-colors hover:text-blue-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Kategoriyalar
            </Link>
            <Link
              href="#narxlar"
              className="text-sm font-medium transition-colors hover:text-blue-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Narxlar
            </Link>
            <Link
              href="#aloqa"
              className="text-sm font-medium transition-colors hover:text-blue-600"
              onClick={() => setIsMenuOpen(false)}
            >
              Aloqa
            </Link>
            {isLoggedIn ? (
              <button
                onClick={() => {
                  handleProfileClick()
                  setIsMenuOpen(false)
                }}
                className="text-sm font-medium transition-colors hover:text-blue-600 flex items-center"
              >
                <User className="h-5 w-5 mr-1" />
                Profil
              </button>
            ) : (
              <>
                <Link
                  href="/login"
                  className="text-sm font-medium transition-colors hover:text-blue-600 flex items-center"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <User className="h-5 w-5 mr-1" />
                  Kirish
                </Link>
                <Link
                  href="/register"
                  className="text-sm font-medium transition-colors hover:text-blue-600 flex items-center"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Ro'yxatdan o'tish
                </Link>
              </>
            )}
          </nav>
        </div>
      )}
    </header>
  )
}
