import Link from "next/link"
import { Facebook, Instagram, Phone, TextIcon as Telegram } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-white border-t">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
                <span className="text-white font-bold">A</span>
              </div>
              <span className="text-xl font-bold text-blue-600">Azizb Xolov</span>
            </Link>
            <p className="text-gray-500 max-w-xs">
              Boysun tumani bo'ylab oziq-ovqat, dori-darmon va boshqa mahsulotlarni yetkazib berish xizmati
            </p>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Kompaniya</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Biz haqimizda
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Vakansiyalar
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Hamkorlik
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Yangiliklar
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Ma'lumot</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Yetkazib berish
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  To'lov usullari
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Savol-javoblar
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-500 hover:text-blue-600 transition-colors">
                  Foydalanish shartlari
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Bog'lanish</h3>
            <div className="space-y-2 text-gray-500">
              <p className="flex items-center">
                <Phone className="h-5 w-5 text-blue-600 mr-2" />
                +998 20 000 58 24
              </p>
              <p>Boysun shahri va atrof qishloqlar</p>
              <p>Ish vaqti: 24/7</p>
              <div className="flex space-x-4 mt-4">
                <Link href="#" className="text-blue-600 hover:text-blue-800">
                  <Telegram className="h-6 w-6" />
                </Link>
                <Link href="#" className="text-blue-600 hover:text-blue-800">
                  <Instagram className="h-6 w-6" />
                </Link>
                <Link href="#" className="text-blue-600 hover:text-blue-800">
                  <Facebook className="h-6 w-6" />
                </Link>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-200 mt-8 pt-8 text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} Azizb Xolov Dastafka. Barcha huquqlar himoyalangan.</p>
        </div>
      </div>
    </footer>
  )
}
