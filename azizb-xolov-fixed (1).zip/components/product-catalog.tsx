"use client"

import Link from "next/link"
import { ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

// Mock data for products
const products = [
  {
    id: 1,
    name: "Non mahsulotlari",
    price: "5 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oziq-ovqat",
  },
  {
    id: 2,
    name: "Sut mahsulotlari",
    price: "15 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oziq-ovqat",
  },
  {
    id: 3,
    name: "Go'sht mahsulotlari",
    price: "45 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oziq-ovqat",
  },
  {
    id: 4,
    name: "Mevalar",
    price: "20 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oziq-ovqat",
  },
  {
    id: 5,
    name: "Ichimliklar",
    price: "12 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oziq-ovqat",
  },
  {
    id: 6,
    name: "Shirinliklar",
    price: "25 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oziq-ovqat",
  },
  {
    id: 7,
    name: "Paracetamol",
    price: "8 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Dori-darmon",
  },
  {
    id: 8,
    name: "Vitaminkompleks",
    price: "35 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Dori-darmon",
  },
  {
    id: 9,
    name: "Sovun",
    price: "6 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Chakana savdo",
  },
  {
    id: 10,
    name: "Shampun",
    price: "18 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Chakana savdo",
  },
  {
    id: 11,
    name: "Qoshiq to'plami",
    price: "30 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oshxona mahsulotlari",
  },
  {
    id: 12,
    name: "Choynak",
    price: "40 000 so'm",
    image: "/placeholder.svg?height=200&width=200",
    category: "Oshxona mahsulotlari",
  },
]

export function ProductCatalog() {
  const router = useRouter()

  const addToCart = (productId: number) => {
    // In a real app, you would add the product to the cart state or localStorage
    // For this demo, we'll just navigate to the cart page
    router.push("/cart")
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {products.map((product) => (
        <div
          key={product.id}
          className="bg-white rounded-lg border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-all"
        >
          <Link href={`/products/${product.id}`} className="block p-3">
            <div className="aspect-square bg-gray-50 rounded-md overflow-hidden mb-3">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="font-medium text-sm mb-1">{product.name}</h3>
            <p className="text-blue-600 font-bold text-sm mb-2">{product.price}</p>
            <p className="text-xs text-gray-500 mb-3">{product.category}</p>
            <Button
              size="sm"
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={(e) => {
                e.preventDefault()
                addToCart(product.id)
              }}
            >
              <ShoppingCart className="h-4 w-4 mr-1" />
              Savatga
            </Button>
          </Link>
        </div>
      ))}
    </div>
  )
}
