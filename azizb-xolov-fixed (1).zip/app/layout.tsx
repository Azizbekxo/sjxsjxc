import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AppDownload } from "@/components/app-download"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Azizb Xolov Dastafka - Boysun tumani yetkazib berish xizmati",
  description: "Boysun tumani bo'ylab oziq-ovqat, dori-darmon va boshqa mahsulotlarni yetkazib berish xizmati",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          <Header />
          <AppDownload />
          {children}
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  )
}
