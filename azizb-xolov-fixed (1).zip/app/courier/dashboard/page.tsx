"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CourierLayout } from "@/components/courier/courier-layout"
import { MapPin, Clock, Phone, Navigation, CheckCircle } from "lucide-react"

// Mock data for orders
const initialOrders = [
  {
    id: 1001,
    customer: "Alisher Karimov",
    phone: "+998 90 123 45 67",
    address: "Boysun shahri, Mustaqillik ko'chasi, 45-uy",
    location: { lat: 41.32, lng: 69.24, address: "Boysun shahri, Mustaqillik ko'chasi, 45-uy" },
    items: [
      { name: "Non mahsulotlari", quantity: 2, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 1, price: "15000" },
    ],
    total: "25000",
    status: "assigned", // assigned, picked, delivered
    assignedTo: "Aziz Xolov",
    date: "2025-05-11T10:30:00",
  },
  {
    id: 1002,
    customer: "Gulnora Azizova",
    phone: "+998 90 987 65 43",
    address: "Boysun shahri, Navoiy ko'chasi, 12-uy",
    location: { lat: 41.31, lng: 69.22, address: "Boysun shahri, Navoiy ko'chasi, 12-uy" },
    items: [{ name: "Go'sht mahsulotlari", quantity: 1, price: "45000" }],
    total: "45000",
    status: "picked", // assigned, picked, delivered
    assignedTo: "Aziz Xolov",
    date: "2025-05-11T09:15:00",
  },
  {
    id: 1003,
    customer: "Bobur Rahimov",
    phone: "+998 90 456 78 90",
    address: "Boysun tumani, Qo'rg'oncha qishlog'i",
    location: { lat: 41.29, lng: 69.25, address: "Boysun tumani, Qo'rg'oncha qishlog'i" },
    items: [
      { name: "Non mahsulotlari", quantity: 3, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 2, price: "15000" },
      { name: "Go'sht mahsulotlari", quantity: 1, price: "45000" },
    ],
    total: "85000",
    status: "delivered", // assigned, picked, delivered
    assignedTo: "Aziz Xolov",
    date: "2025-05-10T16:45:00",
  },
]

export default function CourierDashboard() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [courierName, setCourierName] = useState("")
  const [orders, setOrders] = useState(initialOrders)
  const [activeOrders, setActiveOrders] = useState<any[]>([])
  const [completedOrders, setCompletedOrders] = useState<any[]>([])

  useEffect(() => {
    // Check if courier is authenticated
    const checkAuth = () => {
      const isAuth = localStorage.getItem("courier-auth")
      if (isAuth === "true") {
        setIsAuthenticated(true)
        const name = localStorage.getItem("courier-name")
        if (name) setCourierName(name)
      } else {
        router.push("/courier/login")
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  useEffect(() => {
    // Filter orders by status
    setActiveOrders(orders.filter((order) => order.status === "assigned" || order.status === "picked"))
    setCompletedOrders(orders.filter((order) => order.status === "delivered"))
  }, [orders])

  const updateOrderStatus = (orderId: number, newStatus: string) => {
    const updatedOrders = orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order))
    setOrders(updatedOrders)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge className="bg-blue-500">Yangi</Badge>
      case "picked":
        return <Badge className="bg-yellow-500">Olingan</Badge>
      case "delivered":
        return <Badge className="bg-green-500">Yetkazilgan</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("uz-UZ", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone.replace(/\s/g, "")}`
  }

  const handleNavigate = (location: any) => {
    // In a real app, you would use a maps app to navigate
    if (typeof window !== "undefined" && location && location.lat && location.lng) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`, "_blank")
    } else {
      alert(`Navigating to: ${location?.lat}, ${location?.lng}`)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <CourierLayout courierName={courierName}>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Kuryer paneli</h2>
        </div>

        <Tabs defaultValue="active" className="space-y-4">
          <TabsList>
            <TabsTrigger value="active">Faol buyurtmalar</TabsTrigger>
            <TabsTrigger value="completed">Yakunlangan buyurtmalar</TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-4">
            {activeOrders.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <p className="text-gray-500">Hozirda faol buyurtmalar yo'q</p>
                </CardContent>
              </Card>
            ) : (
              activeOrders.map((order) => (
                <Card key={order.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Buyurtma #{order.id}</CardTitle>
                      {getStatusBadge(order.status)}
                    </div>
                    <CardDescription>{formatDate(order.date)}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-medium mb-2">Mijoz ma'lumotlari</h3>
                        <div className="space-y-2">
                          <p className="text-sm">{order.customer}</p>
                          <div className="flex items-center">
                            <Button
                              variant="outline"
                              size="sm"
                              className="mr-2"
                              onClick={() => handleCall(order.phone)}
                            >
                              <Phone className="h-4 w-4 mr-1" />
                              {order.phone}
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h3 className="font-medium mb-2">Yetkazib berish manzili</h3>
                        <div className="space-y-2">
                          <p className="text-sm">{order.address}</p>
                          <div className="flex items-center">
                            <Button
                              variant="outline"
                              size="sm"
                              className="mr-2"
                              onClick={() => router.push(`/courier/orders/${order.id}`)}
                            >
                              <MapPin className="h-4 w-4 mr-1" />
                              Xaritada ko'rish
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => handleNavigate(order.location)}>
                              <Navigation className="h-4 w-4 mr-1" />
                              Yo'l ko'rsatish
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4">
                      <h3 className="font-medium mb-2">Buyurtma tarkibi</h3>
                      <ul className="space-y-1 text-sm">
                        {order.items.map((item: any, index: number) => (
                          <li key={index}>
                            {item.name} x {item.quantity} - {Number.parseInt(item.price) * item.quantity} so'm
                          </li>
                        ))}
                      </ul>
                      <div className="mt-2 font-bold">Jami: {order.total} so'm</div>
                    </div>
                  </CardContent>

                  <div className="border-t p-4 bg-gray-50">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 text-gray-500 mr-1" />
                        <span className="text-sm text-gray-500">
                          {order.status === "assigned" ? "Yangi buyurtma" : "Olingan buyurtma"}
                        </span>
                      </div>
                      <div>
                        {order.status === "assigned" && (
                          <Button
                            className="bg-blue-600 hover:bg-blue-700"
                            onClick={() => updateOrderStatus(order.id, "picked")}
                          >
                            Buyurtmani oldim
                          </Button>
                        )}
                        {order.status === "picked" && (
                          <Button
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => updateOrderStatus(order.id, "delivered")}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Yetkazib berdim
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {completedOrders.length === 0 ? (
              <Card>
                <CardContent className="py-10 text-center">
                  <p className="text-gray-500">Yakunlangan buyurtmalar yo'q</p>
                </CardContent>
              </Card>
            ) : (
              completedOrders.map((order) => (
                <Card key={order.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Buyurtma #{order.id}</CardTitle>
                      {getStatusBadge(order.status)}
                    </div>
                    <CardDescription>{formatDate(order.date)}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-medium mb-2">Mijoz ma'lumotlari</h3>
                        <p className="text-sm">{order.customer}</p>
                        <p className="text-sm">{order.phone}</p>
                      </div>
                      <div>
                        <h3 className="font-medium mb-2">Yetkazib berish manzili</h3>
                        <p className="text-sm">{order.address}</p>
                        <Button
                          variant="outline"
                          size="sm"
                          className="mt-1"
                          onClick={() => router.push(`/courier/orders/${order.id}`)}
                        >
                          <MapPin className="h-4 w-4 mr-1" />
                          Xaritada ko'rish
                        </Button>
                      </div>
                    </div>

                    <div className="mt-4">
                      <h3 className="font-medium mb-2">Buyurtma tarkibi</h3>
                      <ul className="space-y-1 text-sm">
                        {order.items.map((item: any, index: number) => (
                          <li key={index}>
                            {item.name} x {item.quantity} - {Number.parseInt(item.price) * item.quantity} so'm
                          </li>
                        ))}
                      </ul>
                      <div className="mt-2 font-bold">Jami: {order.total} so'm</div>
                    </div>
                  </CardContent>

                  <div className="border-t p-4 bg-gray-50">
                    <div className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-sm text-green-500">Buyurtma yetkazib berilgan</span>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </CourierLayout>
  )
}
