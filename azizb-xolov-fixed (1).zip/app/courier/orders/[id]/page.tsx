"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CourierLayout } from "@/components/courier/courier-layout"
import { ArrowLeft, Phone, Navigation, CheckCircle } from "lucide-react"
import Link from "next/link"

// Mock data for orders
const initialOrders = [
  {
    id: 1001,
    customer: "Alisher Karimov",
    phone: "+998 90 123 45 67",
    address: "Boysun shahri, Mustaqillik ko'chasi, 45-uy",
    location: { lat: 41.32, lng: 69.24, address: "Boysun shahri, Mustaqillik ko'chasi, 45-uy" },
    items: [
      { name: "Non mahsulotlari", quantity: 2, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 1, price: "15000" },
    ],
    total: "25000",
    status: "assigned", // assigned, picked, delivered
    assignedTo: "Aziz Xolov",
    date: "2025-05-11T10:30:00",
  },
  {
    id: 1002,
    customer: "Gulnora Azizova",
    phone: "+998 90 987 65 43",
    address: "Boysun shahri, Navoiy ko'chasi, 12-uy",
    location: { lat: 41.31, lng: 69.22, address: "Boysun shahri, Navoiy ko'chasi, 12-uy" },
    items: [{ name: "Go'sht mahsulotlari", quantity: 1, price: "45000" }],
    total: "45000",
    status: "picked", // assigned, picked, delivered
    assignedTo: "Aziz Xolov",
    date: "2025-05-11T09:15:00",
  },
  {
    id: 1003,
    customer: "Bobur Rahimov",
    phone: "+998 90 456 78 90",
    address: "Boysun tumani, Qo'rg'oncha qishlog'i",
    location: { lat: 41.29, lng: 69.25, address: "Boysun tumani, Qo'rg'oncha qishlog'i" },
    items: [
      { name: "Non mahsulotlari", quantity: 3, price: "5000" },
      { name: "Sut mahsulotlari", quantity: 2, price: "15000" },
      { name: "Go'sht mahsulotlari", quantity: 1, price: "45000" },
    ],
    total: "85000",
    status: "delivered", // assigned, picked, delivered
    assignedTo: "Aziz Xolov",
    date: "2025-05-10T16:45:00",
  },
]

export default function CourierOrderDetail({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [courierName, setCourierName] = useState("")
  const [order, setOrder] = useState<any>(null)

  useEffect(() => {
    // Check if courier is authenticated
    const checkAuth = () => {
      const isAuth = localStorage.getItem("courier-auth")
      if (isAuth === "true") {
        setIsAuthenticated(true)
        const name = localStorage.getItem("courier-name")
        if (name) setCourierName(name)
      } else {
        router.push("/courier/login")
      }
    }

    checkAuth()

    // Find the order by ID
    const orderId = Number.parseInt(params.id)
    const foundOrder = initialOrders.find((o) => o.id === orderId)
    if (foundOrder) {
      setOrder(foundOrder)
    } else {
      // Order not found, redirect to dashboard
      router.push("/courier/dashboard")
    }

    setIsLoading(false)
  }, [router, params.id])

  const updateOrderStatus = (newStatus: string) => {
    if (!order) return
    setOrder({ ...order, status: newStatus })

    // Update the order in localStorage or send to backend
    const ordersInStorage = initialOrders.map((o) => (o.id === order.id ? { ...o, status: newStatus } : o))

    // In a real app, you would update the order status in the backend
    console.log("Order status updated:", newStatus)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge className="bg-blue-500">Yangi</Badge>
      case "picked":
        return <Badge className="bg-yellow-500">Olingan</Badge>
      case "delivered":
        return <Badge className="bg-green-500">Yetkazilgan</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("uz-UZ", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone.replace(/\s/g, "")}`
  }

  const handleNavigate = (location: any) => {
    // In a real app, you would use a maps app to navigate
    if (typeof window !== "undefined" && location && location.lat && location.lng) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`, "_blank")
    } else {
      alert(`Navigating to: ${location?.lat}, ${location?.lng}`)
    }
  }

  if (isLoading || !order) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <CourierLayout courierName={courierName}>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center mb-6">
          <Link href="/courier/dashboard" className="flex items-center text-gray-600 hover:text-blue-600">
            <ArrowLeft className="h-4 w-4 mr-2" />
            <span>Orqaga qaytish</span>
          </Link>
          <h2 className="text-2xl font-bold ml-auto">Buyurtma #{order.id}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Mijoz ma'lumotlari</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Ism</h3>
                  <p>{order.customer}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Telefon</h3>
                  <Button variant="outline" className="mt-1 w-full" onClick={() => handleCall(order.phone)}>
                    <Phone className="h-4 w-4 mr-2" />
                    {order.phone}
                  </Button>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Manzil</h3>
                  <p>{order.address}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Buyurtma vaqti</h3>
                  <p>{formatDate(order.date)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Holati</h3>
                  <div className="mt-1">{getStatusBadge(order.status)}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Buyurtma tarkibi</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {order.items.map((item: any, index: number) => (
                    <li key={index} className="flex justify-between">
                      <span>
                        {item.name} x {item.quantity}
                      </span>
                      <span className="font-medium">{Number.parseInt(item.price) * item.quantity} so'm</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 pt-4 border-t flex justify-between items-center">
                  <span className="font-bold">Jami:</span>
                  <span className="font-bold text-blue-600">{order.total} so'm</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Mijoz joylashuvi</CardTitle>
                <CardDescription>Yetkazib berish manzili</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-100 w-full h-[400px] rounded-md overflow-hidden relative">
                  {/* In a real app, you would use a map component here */}
                  <img
                    src={`/placeholder.svg?height=400&width=800&text=Map+at+${order.location.lat.toFixed(4)},${order.location.lng.toFixed(4)}`}
                    alt="Joylashuv xaritasi"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-2 right-2 bg-white p-2 rounded-md text-xs">
                    {order.location.lat.toFixed(6)}, {order.location.lng.toFixed(6)}
                  </div>
                </div>

                <div className="mt-4 flex justify-between">
                  <Button variant="outline" onClick={() => handleNavigate(order.location)}>
                    <Navigation className="h-4 w-4 mr-2" />
                    Yo'l ko'rsatish
                  </Button>

                  {order.status === "assigned" && (
                    <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => updateOrderStatus("picked")}>
                      Buyurtmani oldim
                    </Button>
                  )}
                  {order.status === "picked" && (
                    <Button className="bg-green-600 hover:bg-green-700" onClick={() => updateOrderStatus("delivered")}>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Yetkazib berdim
                    </Button>
                  )}
                  {order.status === "delivered" && (
                    <div className="flex items-center text-green-600">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      Buyurtma yetkazib berilgan
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Yetkazib berish yo'riqnomasi</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="list-decimal pl-5 space-y-2">
                  <li>Buyurtmani do'kondan oling</li>
                  <li>Mijozga qo'ng'iroq qiling va yetkazib berish vaqtini tasdiqlang</li>
                  <li>Xaritadan foydalanib mijoz manziliga boring</li>
                  <li>Buyurtmani mijozga topshiring</li>
                  <li>Buyurtma holatini "Yetkazib berildi" ga o'zgartiring</li>
                </ol>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </CourierLayout>
  )
}
