"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Edit, Plus, Trash2 } from "lucide-react"

// Mock data for categories
const initialCategories = [
  { id: 1, name: "Oziq-ovqat", description: "Oziq-ovqat mahsulotlari" },
  { id: 2, name: "Dori-darmon", description: "Dori-darmon mahsulotlari" },
  { id: 3, name: "Chakana savdo", description: "Chakana savdo mahsulotlari" },
  { id: 4, name: "Oshxona mahsulotlari", description: "Oshxona mahsulotlari" },
  { id: 5, name: "Sovg'alar", description: "Sovg'alar" },
  { id: 6, name: "Bolalar uchun", description: "Bolalar uchun mahsulotlar" },
]

export default function AdminCategories() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [categories, setCategories] = useState(initialCategories)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [currentCategory, setCurrentCategory] = useState({
    id: 0,
    name: "",
    description: "",
  })

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = () => {
      const isAuth = localStorage.getItem("admin-auth")
      if (isAuth === "true") {
        setIsAuthenticated(true)
      } else {
        router.push("/admin/login")
      }
      setIsLoading(false)
    }

    checkAuth()
  }, [router])

  const handleAddCategory = () => {
    const newCategory = {
      ...currentCategory,
      id: categories.length > 0 ? Math.max(...categories.map((c) => c.id)) + 1 : 1,
    }
    setCategories([...categories, newCategory])
    setIsAddDialogOpen(false)
    resetCurrentCategory()
  }

  const handleEditCategory = () => {
    const updatedCategories = categories.map((category) =>
      category.id === currentCategory.id ? currentCategory : category,
    )
    setCategories(updatedCategories)
    setIsEditDialogOpen(false)
    resetCurrentCategory()
  }

  const handleDeleteCategory = () => {
    const filteredCategories = categories.filter((category) => category.id !== currentCategory.id)
    setCategories(filteredCategories)
    setIsDeleteDialogOpen(false)
    resetCurrentCategory()
  }

  const resetCurrentCategory = () => {
    setCurrentCategory({
      id: 0,
      name: "",
      description: "",
    })
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <AdminLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Kategoriyalar</h2>
          <Button
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => {
              resetCurrentCategory()
              setIsAddDialogOpen(true)
            }}
          >
            <Plus className="mr-2 h-4 w-4" />
            Yangi kategoriya
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Nomi</TableHead>
                <TableHead>Tavsif</TableHead>
                <TableHead>Amallar</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {categories.map((category) => (
                <TableRow key={category.id}>
                  <TableCell>{category.id}</TableCell>
                  <TableCell>{category.name}</TableCell>
                  <TableCell>{category.description}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setCurrentCategory(category)
                          setIsEditDialogOpen(true)
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          setCurrentCategory(category)
                          setIsDeleteDialogOpen(true)
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Add Category Dialog */}
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yangi kategoriya qo'shish</DialogTitle>
              <DialogDescription>Yangi kategoriya ma'lumotlarini kiriting</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Nomi
                </Label>
                <Input
                  id="name"
                  value={currentCategory.name}
                  onChange={(e) => setCurrentCategory({ ...currentCategory, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="description" className="text-right">
                  Tavsif
                </Label>
                <Input
                  id="description"
                  value={currentCategory.description}
                  onChange={(e) => setCurrentCategory({ ...currentCategory, description: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAddCategory}>
                Qo'shish
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Category Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Kategoriyani tahrirlash</DialogTitle>
              <DialogDescription>Kategoriya ma'lumotlarini o'zgartiring</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-name" className="text-right">
                  Nomi
                </Label>
                <Input
                  id="edit-name"
                  value={currentCategory.name}
                  onChange={(e) => setCurrentCategory({ ...currentCategory, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-description" className="text-right">
                  Tavsif
                </Label>
                <Input
                  id="edit-description"
                  value={currentCategory.description}
                  onChange={(e) => setCurrentCategory({ ...currentCategory, description: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleEditCategory}>
                Saqlash
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Category Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Kategoriyani o'chirish</DialogTitle>
              <DialogDescription>Haqiqatan ham bu kategoriyani o'chirmoqchimisiz?</DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <p>
                <strong>{currentCategory.name}</strong> kategoriyasini o'chirish. Bu amalni ortga qaytarib bo'lmaydi.
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Bekor qilish
              </Button>
              <Button variant="destructive" onClick={handleDeleteCategory}>
                O'chirish
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  )
}
