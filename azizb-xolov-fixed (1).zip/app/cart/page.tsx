"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Minus, Plus, ShoppingBag, Trash2, LogIn, MapPin } from "lucide-react"
import { LocationPicker } from "@/components/location-picker"

// Mock cart items
const initialCartItems = [
  {
    id: 1,
    name: "Non mahsulotlari",
    price: 5000,
    quantity: 2,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    id: 2,
    name: "Sut mahsulotlari",
    price: 15000,
    quantity: 1,
    image: "/placeholder.svg?height=80&width=80",
  },
]

export default function CartPage() {
  const router = useRouter()
  const [cartItems, setCartItems] = useState(initialCartItems)
  const [name, setName] = useState("")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [comment, setComment] = useState("")
  const [orderPlaced, setOrderPlaced] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [location, setLocation] = useState<{ lat: number; lng: number; address: string } | null>(null)
  const [showLocationPicker, setShowLocationPicker] = useState(false)

  useEffect(() => {
    // Check if user is logged in
    const loggedIn = localStorage.getItem("isLoggedIn") === "true"
    setIsLoggedIn(loggedIn)

    // Get user data if logged in
    if (loggedIn) {
      const userJson = localStorage.getItem("user")
      if (userJson) {
        const userData = JSON.parse(userJson)
        setUser(userData)
        setName(userData.fullName || "")
        setPhone(userData.phone || "")
      }
    }
  }, [])

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return

    setCartItems(cartItems.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: number) => {
    setCartItems(cartItems.filter((item) => item.id !== id))
  }

  const calculateSubtotal = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const calculateDeliveryFee = () => {
    // Simple delivery fee calculation
    return 10000
  }

  const calculateTotal = () => {
    return calculateSubtotal() + calculateDeliveryFee()
  }

  const handleLocationSelect = (locationData: { lat: number; lng: number; address: string }) => {
    setLocation(locationData)
    // If the address from location is more specific, update the address field
    if (locationData.address && locationData.address !== "Aniqlangan joylashuv") {
      setAddress(locationData.address)
    }
  }

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault()

    // Check if location is selected
    if (!location) {
      alert("Iltimos, yetkazib berish uchun joylashuvni tanlang")
      return
    }

    // In a real app, you would send the order data including location to your backend
    const orderData = {
      items: cartItems,
      customer: {
        name,
        phone,
        address,
      },
      location,
      comment,
      total: calculateTotal(),
    }

    console.log("Order data:", orderData)

    // Here you would normally send the order to your backend
    setOrderPlaced(true)
  }

  if (orderPlaced) {
    return (
      <div className="container max-w-4xl mx-auto py-12 px-4">
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold mb-4">Buyurtmangiz qabul qilindi!</h1>
          <p className="text-gray-600 mb-8">
            Buyurtmangiz muvaffaqiyatli qabul qilindi. Tez orada siz bilan bog'lanamiz.
          </p>
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/">Asosiy sahifaga qaytish</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <div className="flex items-center mb-8">
        <Link href="/" className="flex items-center text-gray-600 hover:text-blue-600">
          <ArrowLeft className="h-4 w-4 mr-2" />
          <span>Xarid qilishni davom ettirish</span>
        </Link>
        <h1 className="text-2xl font-bold ml-auto">Savatcha</h1>
      </div>

      {cartItems.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="h-8 w-8 text-gray-400" />
          </div>
          <h2 className="text-xl font-bold mb-2">Savatchangiz bo'sh</h2>
          <p className="text-gray-600 mb-6">Mahsulotlarni savatchaga qo'shing va buyurtma bering</p>
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/">Xarid qilishni boshlash</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-4 border-b">
                <h2 className="font-bold">Savatchadagi mahsulotlar ({cartItems.length})</h2>
              </div>
              <div className="divide-y">
                {cartItems.map((item) => (
                  <div key={item.id} className="p-4 flex items-center">
                    <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="ml-4 flex-grow">
                      <h3 className="font-medium">{item.name}</h3>
                      <p className="text-blue-600 font-bold">{item.price.toLocaleString()} so'm</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button
                        className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="ml-4 text-right">
                      <p className="font-bold">{(item.price * item.quantity).toLocaleString()} so'm</p>
                      <button
                        className="text-red-500 mt-1 text-sm flex items-center"
                        onClick={() => removeItem(item.id)}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        O'chirish
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
              <div className="p-4 border-b">
                <h2 className="font-bold">Buyurtma ma'lumotlari</h2>
              </div>
              <div className="p-4 space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Oraliq jami:</span>
                  <span className="font-medium">{calculateSubtotal().toLocaleString()} so'm</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Yetkazib berish:</span>
                  <span className="font-medium">{calculateDeliveryFee().toLocaleString()} so'm</span>
                </div>
                <div className="border-t pt-4 flex justify-between">
                  <span className="font-bold">Jami:</span>
                  <span className="font-bold text-blue-600">{calculateTotal().toLocaleString()} so'm</span>
                </div>
              </div>
            </div>

            {!isLoggedIn ? (
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-4 border-b">
                  <h2 className="font-bold">Buyurtma berish</h2>
                </div>
                <div className="p-6 text-center">
                  <p className="mb-4">Buyurtma berish uchun tizimga kiring yoki ro'yxatdan o'ting</p>
                  <div className="flex flex-col space-y-3">
                    <Button asChild className="bg-blue-600 hover:bg-blue-700">
                      <Link href="/login">
                        <LogIn className="mr-2 h-4 w-4" />
                        Kirish
                      </Link>
                    </Button>
                    <Button asChild variant="outline">
                      <Link href="/register">Ro'yxatdan o'tish</Link>
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-4 border-b">
                  <h2 className="font-bold">Buyurtma berish</h2>
                </div>
                <form onSubmit={handleSubmitOrder} className="p-4 space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="name">
                      Ism-familiya
                    </label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ism-familiyangizni kiriting"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="phone">
                      Telefon raqam
                    </label>
                    <Input
                      id="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+998 XX XXX XX XX"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="address">
                      Manzil
                    </label>
                    <Input
                      id="address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="Yetkazib berish manzilini kiriting"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-sm font-medium">Joylashuv</label>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowLocationPicker(!showLocationPicker)}
                      >
                        {showLocationPicker ? "Yashirish" : "Xaritada ko'rsatish"}
                      </Button>
                    </div>

                    {showLocationPicker && (
                      <LocationPicker onLocationSelect={handleLocationSelect} defaultAddress={address} />
                    )}

                    {location && !showLocationPicker && (
                      <div className="flex items-center text-sm text-green-600">
                        <MapPin className="h-4 w-4 mr-1" />
                        Joylashuv tanlangan
                      </div>
                    )}

                    {!location && !showLocationPicker && (
                      <div className="text-sm text-amber-600">Iltimos, yetkazib berish uchun joylashuvni tanlang</div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium" htmlFor="comment">
                      Izoh
                    </label>
                    <Textarea
                      id="comment"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Qo'shimcha izohlar (ixtiyoriy)"
                      rows={3}
                    />
                  </div>
                  <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                    Buyurtma berish
                  </Button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
